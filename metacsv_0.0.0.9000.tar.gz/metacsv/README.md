
# metacsv

The goal of metacsv is to provide functions for reading and writing
metadata for .csv data files that is either embedded at the top of the
file or in an associated csv file.

## Installation

## Example
